﻿//this lets us detect adblockers so we can adjust the layout in case ads aren't shown ! (we're not using this for anything weird, promise !)
//this works because an adblocker will usually block this file from being embedded at all
var showAds=true;